#!/usr/bin/env bash
# Eerste start: database importeren, hotel-files downloaden, config genereren. Daarna supervisord.
set -Eeuo pipefail
shopt -u patsub_replacement 2> /dev/null || true

H=/opt/hotel
: "${DOMAIN:?DOMAIN ontbreekt}" "${DB_PASSWORD:?DB_PASSWORD ontbreekt}"
DB_HOST=${DB_HOST:-db}
HOTEL_NAME=${HOTEL_NAME:-Hotel}
WS_URL=${WS_URL:-wss://$DOMAIN/ws}
SITE_URL=https://$DOMAIN
SOCKET_URL=$WS_URL
WS_HOST=${WS_URL#*://}; WS_HOST=${WS_HOST%%/*}
FURNIDATA_URL=${FURNIDATA_URL:-$SITE_URL/api/gamedata/furnidata}
ASSET_PACK_URL=${ASSET_PACK_URL:-https://github.com/plus-emulator/plusemu-installer/releases/download/hotel-files/hotel-files.tar.gz}

say() { printf '[hotel] %s\n' "$*"; }
sqlc() { mariadb --skip-ssl -h "$DB_HOST" -uhotel -p"$DB_PASSWORD" "$@"; }

say "Wachten op database..."
until sqlc -e 'SELECT 1' > /dev/null 2>&1; do sleep 2; done

# 1. Database (alleen als er nog geen users-tabel is)
if [ "$(sqlc -N plus -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='plus' AND table_name='users'")" = 0 ]; then
  say "PlusEMU-schema importeren..."
  sqlc plus < "$H/emulator/Database/FreshInstall.sql"
fi

# 2. Hotel-files (~550 MB, éénmalig in het volume)
if [ ! -f "$H/hotel-files/.pack-installed" ]; then
  say "Hotel-files downloaden (kan even duren)..."
  curl -fL --retry 3 "$ASSET_PACK_URL" | tar xz --no-same-owner -C "$H/hotel-files"
  touch "$H/hotel-files/.pack-installed"
fi

# 3. Emulator-config (zelfde instellingen als install.sh; alles draait in dit ene container, dus 127.0.0.1)
cfg=$H/emulator/Config/config.json
sed -i '1s/^\xEF\xBB\xBF//' "$cfg"
sed -i 's/minlevel="Trace"/minlevel="Info"/' "$H/emulator/Config/nlog.config"
jq --arg host "$DB_HOST" --arg pass "$DB_PASSWORD" '
  .Database.Hostname = $host | .Database.Port = 3306 | .Database.Username = "hotel"
  | .Database.Password = $pass | .Database.Name = "plus"
  | .Flash.Hostname = "127.0.0.1"
  | .Nitro.Hostname = "127.0.0.1" | .Nitro.Port = 2096 | .Nitro.Name = "Volt"
  | .Rcon.Hostname = "127.0.0.1" | .Rcon.Port = 30001 | .Rcon.AllowedAddresses = ["127.0.0.1", "localhost"]' \
  "$cfg" > "$cfg.new"
cat "$cfg.new" > "$cfg"; rm -f "$cfg.new"
chown -R plusemu:plusemu "$H/emulator"

# 4. Client-config uit de installer-templates
render() {
  local c k; c=$(< "$1")
  for k in SITE_URL SOCKET_URL FURNIDATA_URL DOMAIN HOTEL_NAME WS_HOST; do c=${c//"{{$k}}"/${!k}}; done
  printf '%s\n' "$c" > "$2"
}
mkdir -p "$H/client/configuration"
for f in renderer-config.json ui-config.json client-mode.json; do
  render "/opt/installer/templates/$f" "$H/client/configuration/$f"
done

# 5. Atom CMS (.env leeft in het storage-volume, dus overleeft herstarts)
set_env() {
  local file=$1 key=$2 value=$3
  value=${value//\\/\\\\}; value=${value//\"/\\\"}
  if grep -q "^$key=" "$file"; then sed -i "s|^$key=.*|$key=\"${value//|/\\|}\"|" "$file"
  else printf '%s="%s"\n' "$key" "$value" >> "$file"; fi
}
envf=$H/cms/storage/.env
[ -f "$envf" ] || cp "$H/cms/.env.example" "$envf"
set_env "$envf" APP_ENV production
set_env "$envf" APP_DEBUG false
set_env "$envf" APP_URL "$SITE_URL"
set_env "$envf" DB_CONNECTION mariadb
set_env "$envf" DB_HOST "$DB_HOST"
set_env "$envf" DB_PORT 3306
set_env "$envf" DB_DATABASE plus
set_env "$envf" DB_USERNAME hotel
set_env "$envf" DB_PASSWORD "$DB_PASSWORD"
set_env "$envf" EMULATOR_DRIVER plus
set_env "$envf" CLIENT_NITRO_ENABLED true
set_env "$envf" NITRO_CLIENT_PATH "$SITE_URL/client"
set_env "$envf" RCON_HOST 127.0.0.1
set_env "$envf" RCON_PORT 30001
set_env "$envf" FORCE_HTTPS true
set_env "$envf" SESSION_SECURE_COOKIE true
set_env "$envf" TRUSTED_PROXIES 127.0.0.1
cd "$H/cms"
grep -q '^APP_KEY=.\+' "$envf" || php artisan key:generate --force
php artisan storage:link > /dev/null 2>&1 || true
php artisan optimize:clear > /dev/null 2>&1 || true
chown -R www-data:www-data "$H/cms/storage" "$H/cms/bootstrap/cache"

# Paden in de website-instellingen (zoals install.sh; alleen als de tabel al bestaat)
if [ "$(sqlc -N plus -e "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='plus' AND table_name='website_settings'")" = 1 ]; then
  sqlc plus <<SQL
UPDATE website_settings SET value = CASE \`key\`
    WHEN 'nitro_path' THEN '$SITE_URL/client'
    WHEN 'rcon_ip' THEN '127.0.0.1'
    WHEN 'rcon_port' THEN '30001'
    WHEN 'badges_path' THEN '$SITE_URL/hotel-files/c_images/album1584'
    WHEN 'furniture_icons_path' THEN '$SITE_URL/hotel-files/c_images/hof_furni/icons'
    ELSE value END
WHERE \`key\` IN ('nitro_path', 'rcon_ip', 'rcon_port', 'badges_path', 'furniture_icons_path');
SQL
fi

say "Starten..."
exec /usr/bin/supervisord -n -c /etc/supervisor/supervisord.conf
